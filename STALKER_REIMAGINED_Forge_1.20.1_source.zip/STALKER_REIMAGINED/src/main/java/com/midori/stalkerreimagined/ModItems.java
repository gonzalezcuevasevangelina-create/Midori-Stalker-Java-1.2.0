package com.midori.stalkerreimagined;

import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, StalkerReimagined.MODID);

    public static final RegistryObject<Item> ENEMYTE = ITEMS.register("enemyte", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ENEMYTE_SWORD = ITEMS.register("enemyte_sword", () -> new SwordItem(EnemyteTier.INSTANCE, 3, -2.4F, new Item.Properties()));
    public static final RegistryObject<Item> ENEMYTE_PICKAXE = ITEMS.register("enemyte_pickaxe", () -> new PickaxeItem(EnemyteTier.INSTANCE, 1, -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> ENEMYTE_AXE = ITEMS.register("enemyte_axe", () -> new AxeItem(EnemyteTier.INSTANCE, 5.0F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> ENEMYTE_SHOVEL = ITEMS.register("enemyte_shovel", () -> new ShovelItem(EnemyteTier.INSTANCE, 1.5F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> ENEMYTE_HOE = ITEMS.register("enemyte_hoe", () -> new HoeItem(EnemyteTier.INSTANCE, -3, 0.0F, new Item.Properties()));

    /** un huevo de aparicion por stalker (con la textura de oval) */
    public static final List<RegistryObject<Item>> EGGS = new ArrayList<>();

    static {
        for (StalkerType t : StalkerType.values()) {
            EGGS.add(ITEMS.register(t.id + "_spawn_egg",
                    () -> new ForgeSpawnEggItem(StalkerReimagined.TYPES.get(t), 0x111111, 0xAA3344, new Item.Properties())));
        }
    }

    private ModItems() {}
}
