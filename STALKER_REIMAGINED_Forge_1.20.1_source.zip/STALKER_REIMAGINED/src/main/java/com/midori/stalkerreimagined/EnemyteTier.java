package com.midori.stalkerreimagined;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Herramientas de Enemyte: mismas estadisticas que el diamante (1561 usos). */
public enum EnemyteTier implements Tier {
    INSTANCE;

    @Override public int getUses() { return 1561; }
    @Override public float getSpeed() { return 8.0F; }
    @Override public float getAttackDamageBonus() { return 3.0F; }
    @Override public int getLevel() { return 3; }
    @Override public int getEnchantmentValue() { return 10; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(ModItems.ENEMYTE.get()); }
}
