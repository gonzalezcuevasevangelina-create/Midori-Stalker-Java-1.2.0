package com.midori.stalkerreimagined;

/** Generado a partir del addon de Bedrock: tamano, vida, velocidad, texturas y plano de cada stalker. */
public enum StalkerType {
    BOILED_ONE("boiled_one", Kind.BOILED, 0.8f, 4.0f, 20, 0.3, 0, new String[]{"boiled_one"}, new double[][]{{-0.49802,0.00000,0.49802,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    CAVE_STALKER("cave_stalker", Kind.CAVE, 0.8f, 4.0f, 20, 0.3, 0, new String[]{"cave_stalker"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    DOOR_STALK("door_stalk", Kind.DOOR_STALK, 0.8f, 2.0f, 20, 0.3, 0, new String[]{"door_stalk"}, new double[][]{{-0.96979,0.00000,0.96979,2.00000,0.00000,0.00000,1.00000,1.00000}}),
    EVENT_STALKER("event_stalker", Kind.FAR_LOOK, 1.0f, 4.0f, 30, 0.3, 5, new String[]{"event_look1","event_look2"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    EVILSTALKER("evilstalker", Kind.FAR_LOOK, 1.5f, 4.0f, 40, 0.3, 6, new String[]{"evilstalker_observe","evilstalker_chase"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    HAND("hand", Kind.HAND, 0.6f, 2.5f, 20, 0.3, 0, new String[]{"hand"}, new double[][]{{-1.25000,0.00000,1.25000,2.50000,0.00000,0.00000,1.00000,1.00000}}),
    HAND_2("hand_2", Kind.HAND2, 0.6f, 2.5f, 20, 0.3, 0, new String[]{"hand_2"}, new double[][]{{-1.25000,0.00000,1.25000,2.50000,0.00000,0.00000,1.00000,1.00000}}),
    HUNTER_STALKER("hunter_stalker", Kind.HUNTER, 0.7f, 4.0f, 40, 0.32, 4, new String[]{"hunter_stalker"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    LUSTER_STALKER("luster_stalker", Kind.FAR_LOOK, 1.0f, 3.2f, 30, 0.3, 5, new String[]{"luster_stalk","luster_chase"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    ORIMMY_STALKER("orimmy_stalker", Kind.FAR_LOOK, 0.8f, 4.0f, 30, 0.3, 5, new String[]{"orimmy_stalk","orimmy_chase"}, new double[][]{{-0.52068,0.00000,0.52068,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    PEEKING_STALKER("peeking_stalker", Kind.PEEKING, 0.8f, 2.0f, 20, 0.3, 0, new String[]{"peeking_pose0","peeking_pose1","peeking_pose2"}, new double[][]{{-1.44093,0.10097,1.22996,2.60097,0.00000,0.00000,1.00000,1.00000}}),
    SILENT_DISTORSIONADO("silent_distorsionado", Kind.DISTORTED, 0.7f, 5.5f, 30, 0.3, 0, new String[]{"silent_distorsionado"}, new double[][]{{-1.37500,0.00000,1.37500,5.50000,0.00000,0.00000,1.00000,1.00000}}),
    SILENT_HABLANDO("silent_hablando", Kind.FREEZE, 0.9f, 4.0f, 30, 0.3, 5, new String[]{"silent_hablando"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    SILENT_STALKER("silent_stalker", Kind.FREEZE, 0.6f, 4.0f, 30, 0.3, 5, new String[]{"silent_stalker"}, new double[][]{{-1.00000,0.00000,1.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    STALKER("stalker", Kind.FREEZE, 0.8f, 4.0f, 30, 0.3, 5, new String[]{"stalker"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    STALKER_BIPEDAL_DOOR("stalker_bipedal_door", Kind.FREEZE, 0.8f, 4.0f, 30, 0.3, 5, new String[]{"stalker_bipedal_door","stalker_bipedal_door_away"}, new double[][]{{-4.00000,0.00000,4.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    THE_FOLLOWER("the_follower", Kind.FOLLOWER, 0.8f, 4.0f, 20, 0.3, 0, new String[]{"the_follower"}, new double[][]{{-0.85632,0.00000,0.85632,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    THE_LOCUST("the_locust", Kind.LOCUST, 0.9f, 6.0f, 30, 0.3, 5, new String[]{"locust"}, new double[][]{{-0.94737,1.30994,0.94737,6.00000,0.00000,0.00000,0.63780,1.00000},{-0.59649,0.00000,-0.10526,1.67251,0.65354,0.00000,0.81890,0.35661},{-0.10526,0.00000,0.38596,1.67251,0.83465,0.00000,1.00000,0.35661}}),
    TORMENTOR("tormentor", Kind.TORMENT, 1.5f, 5.0f, 40, 0.3, 6, new String[]{"tormentor"}, new double[][]{{-2.50000,0.00000,2.50000,5.00000,0.00000,0.00000,1.00000,1.00000}}),
    TORMENTOR_DOOR("tormentor_door", Kind.TORMENT_DOOR, 0.8f, 2.0f, 20, 0.3, 0, new String[]{"tormentor_door0","tormentor_door_pose1","tormentor_door_pose2"}, new double[][]{{-2.00000,0.00000,2.00000,4.00000,0.00000,0.00000,1.00000,1.00000}}),
    TREE_STALKER("tree_stalker", Kind.TREE, 0.8f, 2.5f, 20, 0.3, 0, new String[]{"tree_stalker"}, new double[][]{{-1.25000,0.00000,1.25000,2.50000,0.00000,0.00000,1.00000,1.00000}}),
    YELLING_STALKER("yelling_stalker", Kind.YELLING, 0.8f, 4.0f, 20, 0.3, 5, new String[]{"yelling_pose0","yelling_pose1","yelling_pose2","yelling_pose3","yelling_pose4","yelling_pose5"}, new double[][]{{-1.48194,0.00000,1.86962,4.00000,0.00000,0.00000,1.00000,1.00000}});

    public enum Kind { FREEZE, HUNTER, FAR_LOOK, YELLING, TORMENT, CAVE, DOOR_STALK, HAND, HAND2, PEEKING, TORMENT_DOOR, TREE, BOILED, LOCUST, FOLLOWER, DISTORTED }

    public final String id;
    public final Kind kind;
    public final float width, height;
    public final double health, speed, damage;
    public final String[] textures;
    /** cada plano: x0, y0, x1, y1 (bloques) y u0, v0, u1, v1 */
    public final double[][] quads;

    StalkerType(String id, Kind kind, float width, float height, double health, double speed, double damage, String[] textures, double[][] quads) {
        this.id = id; this.kind = kind; this.width = width; this.height = height;
        this.health = health; this.speed = speed; this.damage = damage; this.textures = textures; this.quads = quads;
    }
}
